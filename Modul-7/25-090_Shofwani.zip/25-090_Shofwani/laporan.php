
<?php
include "koneksi.php";

// Mengambil tanggal dari form
$tanggal_mulai = $_GET['tanggal_mulai'] ?? '';
$tanggal_selesai = $_GET['tanggal_selesai'] ?? '';

$data = [];
$total_pendapatan = 0;
$jumlah_pelanggan = 0;
$valid = false;

// Memeriksa tanggal
if (
    $tanggal_mulai !== '' &&
    $tanggal_selesai !== '' &&
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_mulai) &&
    preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_selesai) &&
    $tanggal_mulai <= $tanggal_selesai
) {
    $valid = true;

    // Mengambil rekap penjualan harian
    $sql = "SELECT
                DATE(waktu_transaksi) AS tanggal,
                SUM(total) AS total_pendapatan
            FROM transaksi
            WHERE waktu_transaksi >= ?
            AND waktu_transaksi < DATE_ADD(?, INTERVAL 1 DAY)
            GROUP BY DATE(waktu_transaksi)
            ORDER BY DATE(waktu_transaksi) ASC";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss",
        $tanggal_mulai, $tanggal_selesai
    );
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    mysqli_stmt_close($stmt);

    // Menghitung total pendapatan dan pelanggan unik
    $sql_total = "SELECT
                    COUNT(DISTINCT pelanggan_id) AS jumlah_pelanggan,
                    COALESCE(SUM(total), 0) AS total_pendapatan
                  FROM transaksi
                  WHERE waktu_transaksi >= ?
                  AND waktu_transaksi < DATE_ADD(?, INTERVAL 1 DAY)";

    $stmt = mysqli_prepare($conn, $sql_total);
    mysqli_stmt_bind_param($stmt, "ss",
        $tanggal_mulai, $tanggal_selesai
    );
    mysqli_stmt_execute($stmt);

    $result_total = mysqli_stmt_get_result($stmt);
    $ringkasan = mysqli_fetch_assoc($result_total);

    $jumlah_pelanggan = $ringkasan['jumlah_pelanggan'];
    $total_pendapatan = $ringkasan['total_pendapatan'];

    mysqli_stmt_close($stmt);
}

// Data untuk grafik
$labels = [];
$values = [];

foreach ($data as $row) {
    $labels[] = $row['tanggal'];
    $values[] = (int) $row['total_pendapatan'];
}

function rupiah($angka) {
    return "Rp " . number_format($angka, 0, ',', '.');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporting Penjualan</title>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 25px;
        }

        .container {
            max-width: 1100px;
            margin: auto;
        }

        h2 {
            color: #1e3a8a;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        }

        .filter {
            display: flex;
            gap: 15px;
            align-items: end;
            flex-wrap: wrap;
        }

        .filter div {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        input {
            padding: 9px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button, .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .tampilkan { background: #2563eb; }
        .cetak { background: #16a34a; }
        .excel { background: #15803d; }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .ringkasan {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .angka {
            font-size: 25px;
            font-weight: bold;
            color: #2563eb;
        }

        @media(max-width: 600px) {
            .ringkasan {
                grid-template-columns: 1fr;
            }
        }

        @media print {
            body {
                background: white;
                padding: 0;
            }

            .no-print {
                display: none !important;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Reporting Laporan Penjualan</h2>
    <p>Laporan rekapitulasi penjualan berdasarkan periode tanggal.</p>

    <!-- Form Filter -->
    <div class="card no-print">

        <form method="GET" class="filter">

            <div>
                <label>Tanggal Mulai</label>
                <input type="date" name="tanggal_mulai"
                    value="<?= htmlspecialchars($tanggal_mulai) ?>"
                    required>
            </div>

            <div>
                <label>Tanggal Selesai</label>
                <input type="date" name="tanggal_selesai"
                    value="<?= htmlspecialchars($tanggal_selesai) ?>"
                    required>
            </div>

            <button type="submit" class="tampilkan">
                Tampilkan
            </button>

        </form>

        <?php if ($tanggal_mulai !== '' && !$valid): ?>
            <p style="color:red">
                Tanggal tidak valid. Periksa kembali rentang tanggal.
            </p>
        <?php endif; ?>

    </div>

    <?php if ($valid): ?>

    <div class="card">
        <h3>Grafik Penjualan Harian</h3>

        <canvas id="grafikPenjualan"></canvas>
    </div>

    <div class="card">
        <h3>Rekapitulasi Penjualan Harian</h3>

        <p>
            Periode:
            <?= htmlspecialchars($tanggal_mulai) ?>
            sampai
            <?= htmlspecialchars($tanggal_selesai) ?>
        </p>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Total Pendapatan</th>
                    <th>Tanggal Transaksi</th>
                </tr>
            </thead>

            <tbody>
                <?php if (count($data) > 0): ?>

                    <?php $no = 1; ?>

                    <?php foreach ($data as $row): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <?= rupiah($row['total_pendapatan']) ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($row['tanggal']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="3" style="text-align:center">
                            Tidak ada data penjualan pada periode ini.
                        </td>
                    </tr>

                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Ringkasan -->
    <div class="ringkasan">

        <div class="card">
            <h3>Jumlah Pelanggan Unik</h3>
            <div class="angka">
                <?= number_format($jumlah_pelanggan, 0, ',', '.') ?>
            </div>
            <p>Total pelanggan berbeda pada periode tersebut.</p>
        </div>

        <div class="card">
            <h3>Total Pendapatan Keseluruhan</h3>
            <div class="angka">
                <?= rupiah($total_pendapatan) ?>
            </div>
            <p>Akumulasi seluruh transaksi pada periode tersebut.</p>
        </div>

    </div>

    <!-- Tombol Cetak dan Excel -->
    <div class="card no-print">

        <button onclick="window.print()" class="cetak">
            Cetak Laporan
        </button>

        <a class="btn excel"
           href="export_excel.php?tanggal_mulai=<?= urlencode($tanggal_mulai) ?>&tanggal_selesai=<?= urlencode($tanggal_selesai) ?>">
            Ekspor Excel
        </a>

    </div>

    <?php endif; ?>

</div>

<script>
const labels = <?= json_encode($labels) ?>;
const values = <?= json_encode($values) ?>;

const ctx = document.getElementById('grafikPenjualan');

if (ctx) {
    new Chart(ctx, {
        type: 'bar',

        data: {
            labels: labels,

            datasets: [{
                label: 'Total Pendapatan (Rupiah)',
                data: values,
                backgroundColor: '#3b82f6',
                borderColor: '#1d4ed8',
                borderWidth: 1
            }]
        },

        options: {
            responsive: true,

            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Total Pendapatan (Rupiah)'
                    }
                },

                x: {
                    title: {
                        display: true,
                        text: 'Tanggal Transaksi'
                    }
                }
            }
        }
    });
}
</script>

</body>
</html>
