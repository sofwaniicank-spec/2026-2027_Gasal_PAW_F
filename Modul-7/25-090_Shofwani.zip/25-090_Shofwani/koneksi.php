
<?php
$conn = mysqli_connect("localhost", "root", "", "reporting_penjualan");

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
