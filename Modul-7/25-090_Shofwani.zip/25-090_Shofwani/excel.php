
<?php
require_once "koneksi.php";

// Mengambil tanggal dari URL
$tanggal_mulai = $_GET['tanggal_mulai'] ?? '';
$tanggal_selesai = $_GET['tanggal_selesai'] ?? '';

// Validasi tanggal
if (
    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_mulai) ||
    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_selesai) ||
    $tanggal_mulai > $tanggal_selesai
) {
    die("Tanggal tidak valid!");
}

// Query data
$sql = "SELECT
            DATE(waktu_transaksi) AS tanggal,
            SUM(total) AS total_pendapatan
        FROM transaksi
        WHERE waktu_transaksi >= ?
        AND waktu_transaksi < DATE_ADD(?, INTERVAL 1 DAY)
        GROUP BY DATE(waktu_transaksi)
        ORDER BY tanggal ASC";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("Query gagal: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ss", $tanggal_mulai, $tanggal_selesai);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

// Header download Excel
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=laporan_penjualan.xls");
header("Cache-Control: max-age=0");

// Membuat tabel Excel
echo "<table border='1'>";

echo "<tr>
        <th>No</th>
        <th>Total Pendapatan</th>
        <th>Tanggal Transaksi</th>
      </tr>";

$no = 1;

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $no++ . "</td>";
    echo "<td>" . $row['total_pendapatan'] . "</td>";
    echo "<td>" . $row['tanggal'] . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_stmt_close($stmt);
mysqli_close($conn);
exit;
?>
